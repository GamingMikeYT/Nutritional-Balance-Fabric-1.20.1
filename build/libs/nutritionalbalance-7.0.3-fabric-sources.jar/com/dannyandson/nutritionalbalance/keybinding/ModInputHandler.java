
package com.dannyandson.nutritionalbalance.keybinding;

import com.dannyandson.nutritionalbalance.network.GUITrigger;
import com.dannyandson.nutritionalbalance.network.ModNetworkHandler;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_304;

public class ModInputHandler {

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            class_304 nutrientKey =
                    ModKeyBindings.keyBindings.get("nutrientgui");

            if (nutrientKey != null && nutrientKey.method_1436()) {
                ModNetworkHandler.sendToServer(new GUITrigger());
            }
        });
    }
}
