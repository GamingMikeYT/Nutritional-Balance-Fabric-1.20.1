package com.dannyandson.nutritionalbalance.keybinding;

import com.dannyandson.nutritionalbalance.NutritionalBalance;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import java.util.HashMap;
import java.util.Map;

public class ModKeyBindings {

    public static Map<String, class_304> keyBindings = new HashMap<>();

    public static void init() {
        class_304 nutritionguikeybind = KeyBindingHelper.registerKeyBinding(
                new class_304(
                        "key." + NutritionalBalance.MODID + ".opennutrientgui",
                        class_3675.class_307.field_1668,
                        78,
                        "Nutritional Balance"
                )
        );

        keyBindings.put("nutrientgui", nutritionguikeybind);
    }
}