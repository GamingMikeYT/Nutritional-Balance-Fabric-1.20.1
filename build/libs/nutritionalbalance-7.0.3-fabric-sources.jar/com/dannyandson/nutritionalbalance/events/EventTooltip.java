package com.dannyandson.nutritionalbalance.events;

import com.dannyandson.nutritionalbalance.NutritionalBalance;
import com.dannyandson.nutritionalbalance.nutrients.Nutrient;
import com.dannyandson.nutritionalbalance.nutrients.WorldNutrients;

import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.class_1074;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2272;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4174;
import net.minecraft.class_437;
import net.minecraft.class_6862;
import java.util.List;
import java.util.StringJoiner;

public class EventTooltip {

    public static void init() {

        ItemTooltipCallback.EVENT.register((itemStack, context, tooltip) -> {

            class_1792 item = itemStack.method_7909();

            class_1937 world = class_310.method_1551().field_1687;

            if (world == null) {
                NutritionalBalance.LOGGER.error(
                        "Exception during attempt to access tooltip without a world."
                );
                return;
            }

            class_4174 foodComponent = item.method_19264();

            boolean isCake =
                    item instanceof class_1747 blockItem
                            && blockItem.method_7711() instanceof class_2272;

            if (foodComponent != null || isCake) {

                StringJoiner stringJoiner = new StringJoiner(", ");

                try {

                    List<Nutrient> nutrients =
                            WorldNutrients.getNutrients(itemStack, world);

                    if (nutrients != null) {

                        for (Nutrient nutrient : nutrients) {
                            stringJoiner.add(nutrient.getLocalizedName());
                        }

                        if (stringJoiner.length() > 0) {

                            String NUvalue = "";

                            if (foodComponent != null) {
                                NUvalue =
                                        " ("
                                                + ((float) Math.round(
                                                WorldNutrients.getEffectiveFoodQuality(
                                                        foodComponent,
                                                        nutrients.size()
                                                ) * 10
                                        )) / 10
                                                + "NU)";
                            }

                            tooltip.add(
                                    class_2561.method_43470(
                                            "§7"
                                                    + class_1074.method_4662(
                                                    "nutritionalbalance.nutrients"
                                            )
                                                    + ": §2"
                                                    + stringJoiner
                                                    + "§7"
                                                    + NUvalue
                                                    + "§r"
                                    )
                            );
                        }
                    }

                    /*
                     * Preserve the original developer-only tag display.
                     */
                    if (class_310.method_1551().field_1724 != null
                            && class_310.method_1551()
                            .field_1724
                            .method_5476()
                            .getString()
                            .equals("Dev")
                            && class_310.method_1551()
                            .field_1690
                            .field_1827) {

                        if (class_437.method_25442()) {

                            for (class_6862<class_1792> tagKey :
                                    itemStack.method_40133().toList()) {

                                tooltip.add(
                                        class_2561.method_43470(
                                                "#" + tagKey.comp_327().toString()
                                        )
                                );
                            }

                        } else {

                            tooltip.add(
                                    class_2561.method_43470(
                                            "§8--Hold shift for tag info--§r"
                                    )
                            );
                        }
                    }

                } catch (Exception e) {

                    NutritionalBalance.LOGGER.error(
                            "Exception thrown while adding nutrient info for '"
                                    + itemStack.method_7964().getString()
                                    + "' to tooltips: "
                                    + e.getMessage()
                    );
                }
            }
        });
    }
}