package com.dannyandson.nutritionalbalance.events;

import com.dannyandson.nutritionalbalance.Config;
import com.dannyandson.nutritionalbalance.NutritionalBalance;
import com.dannyandson.nutritionalbalance.api.INutritionalBalancePlayer;
import com.dannyandson.nutritionalbalance.api.IPlayerNutrient;
import com.dannyandson.nutritionalbalance.effects.ModMobAffects;
import com.dannyandson.nutritionalbalance.network.ModNetworkHandler;
import com.dannyandson.nutritionalbalance.network.PlayerSync;
import com.dannyandson.nutritionalbalance.nutrients.PlayerNutritionData;
import com.dannyandson.nutritionalbalance.setup.Registration;

import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_3222;

public class EventPlayerTick {

    public static void init() {

        /*
         * Fabric does not have NeoForge's PlayerTickEvent.
         *
         * SERVER_TICK runs once per server tick, so we iterate through
         * the server's players and perform the same per-player logic.
         */
        ServerTickEvents.END_SERVER_TICK.register(server -> {

            for (class_3222 playerEntity : server.method_3760().method_14571()) {

                INutritionalBalancePlayer iNutritionalBalancePlayer =
                        PlayerNutritionData.getWorldNutritionData()
                                .getNutritionalBalancePlayer(playerEntity);

                if (!NutritionalBalance.modEffectsLoaded) {
                    ModMobAffects.loadModEffects();
                }

                float playerSaturation =
                        playerEntity.method_7344().method_7589();

                int playerFoodLevel =
                        playerEntity.method_7344().method_7586();

                float foodpoints = playerSaturation + playerFoodLevel;

                System.out.println("[Nutrient Decay Debug] EventPlayerTick is calling processSaturationChange()");
                iNutritionalBalancePlayer.processSaturationChange(foodpoints);

                /*
                 * 200 ticks = 10 seconds, same as the original.
                 */
                if (playerEntity.field_6012 % 200 == 0) {

                    IPlayerNutrient.NutrientStatus cachedStatus =
                            iNutritionalBalancePlayer.getCachedStatus();

                    IPlayerNutrient.NutrientStatus currentStatus =
                            iNutritionalBalancePlayer.getStatus();

                    class_1291 nourishedEffect =
                            Registration.NOURISHED_EFFECT;

                    class_1291 malnourishedEffect =
                            Registration.MALNOURISHED_EFFECT;

                    class_1291 engorgedEffect =
                            Registration.ENGORGED_EFFECT;

                    class_1293 nourished =
                            playerEntity.method_6112(nourishedEffect);

                    class_1293 malnourished =
                            playerEntity.method_6112(malnourishedEffect);

                    class_1293 engorged =
                            playerEntity.method_6112(engorgedEffect);

                    if (currentStatus == IPlayerNutrient.NutrientStatus.ENGORGED) {

                        if (nourished != null)
                            playerEntity.method_6016(nourishedEffect);

                        if (malnourished != null)
                            playerEntity.method_6016(malnourishedEffect);

                        if (engorged == null) {
                            playerEntity.method_6092(
                                    new class_1293(
                                            engorgedEffect,
                                            Integer.MAX_VALUE,
                                            0,
                                            true,
                                            false,
                                            true
                                    )
                            );
                        }

                    } else if (currentStatus == IPlayerNutrient.NutrientStatus.MALNOURISHED) {

                        if (nourished != null)
                            playerEntity.method_6016(nourishedEffect);

                        if (malnourished == null) {
                            playerEntity.method_6092(
                                    new class_1293(
                                            malnourishedEffect,
                                            Integer.MAX_VALUE,
                                            0,
                                            true,
                                            false,
                                            true
                                    )
                            );
                        }

                        if (engorged != null)
                            playerEntity.method_6016(engorgedEffect);

                    } else if (currentStatus == IPlayerNutrient.NutrientStatus.ON_TARGET) {

                        if (nourished == null) {
                            playerEntity.method_6092(
                                    new class_1293(
                                            nourishedEffect,
                                            Integer.MAX_VALUE,
                                            0,
                                            true,
                                            false,
                                            true
                                    )
                            );
                        }

                        if (malnourished != null)
                            playerEntity.method_6016(malnourishedEffect);

                        if (engorged != null)
                            playerEntity.method_6016(engorgedEffect);

                    } else {

                        if (nourished != null)
                            playerEntity.method_6016(nourishedEffect);

                        if (malnourished != null)
                            playerEntity.method_6016(malnourishedEffect);

                        if (engorged != null)
                            playerEntity.method_6016(engorgedEffect);
                    }

                    /*
                     * Synchronize the nutrient data/status with the client
                     * whenever the cached status changes.
                     */
                    if (cachedStatus != currentStatus) {

                        if (Config.SHOW_THRESHOLD_TOAST.get()) {
                            ClientHelpers.showStatusToast(currentStatus.name());
                        }

                        PlayerSync playerSync =
                                new PlayerSync(iNutritionalBalancePlayer);

                        ModNetworkHandler.sendToClient(
                                playerSync,
                                playerEntity
                        );
                    }
                }
            }
        });
    }
}
