package com.dannyandson.nutritionalbalance.events;

import com.dannyandson.nutritionalbalance.Config;
import com.dannyandson.nutritionalbalance.api.INutritionalBalancePlayer;
import com.dannyandson.nutritionalbalance.nutrients.Nutrient;
import com.dannyandson.nutritionalbalance.nutrients.PlayerNutritionData;
import com.dannyandson.nutritionalbalance.nutrients.WorldNutrients;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2272;
import net.minecraft.class_2680;
import java.util.List;

public class EventRightClickBlock {

    public static void init() {

        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {

            class_2680 blockState = world.method_8320(hitResult.method_17777());
            class_2248 block = blockState.method_26204();

            if (block instanceof class_2272) {

                if (!world.field_9236 && player.method_7332(false)) {

                    INutritionalBalancePlayer iNutritionalBalancePlayer =
                            PlayerNutritionData.getWorldNutritionData()
                                    .getNutritionalBalancePlayer(player);

                    class_1792 cakeItem = block.method_8389();

                    List<Nutrient> nutrients =
                            WorldNutrients.getNutrients(cakeItem, world);

                    for (Nutrient nutrient : nutrients) {

                        float nutrientunits =
                                2.4f
                                        * Config.NUTRIENT_INCREMENT_RATE.get().floatValue()
                                        / nutrients.size();

                        iNutritionalBalancePlayer
                                .getPlayerNutrientByName(nutrient.name)
                                .changeValue(nutrientunits);

                        PlayerNutritionData.getWorldNutritionData().setDirty();
                    }
                }
            }

            return class_1269.field_5811;
        });
    }
}