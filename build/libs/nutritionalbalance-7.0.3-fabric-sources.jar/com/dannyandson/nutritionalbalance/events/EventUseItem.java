package com.dannyandson.nutritionalbalance.events;

import com.dannyandson.nutritionalbalance.api.INutritionalBalancePlayer;
import com.dannyandson.nutritionalbalance.nutrients.PlayerNutritionData;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3222;

public class EventUseItem {

    public static void onUseItemFinish(class_1799 item, class_1937 world, class_3222 player) {
        if (item.method_7909().method_19264() != null) {

            System.out.println("[Nutrient Debug] EventUseItem received: " + item.method_7909());

            INutritionalBalancePlayer iNutritionalBalancePlayer =
                    PlayerNutritionData.getWorldNutritionData()
                            .getNutritionalBalancePlayer(player);

            System.out.println("[Nutrient Debug] Calling consume...");
            iNutritionalBalancePlayer.consume(item, world);
            System.out.println("[Nutrient Debug] consume returned.");

            PlayerNutritionData.getWorldNutritionData().setDirty();
            System.out.println("[Nutrient Debug] World nutrition data marked dirty.");
        }
    }
}
