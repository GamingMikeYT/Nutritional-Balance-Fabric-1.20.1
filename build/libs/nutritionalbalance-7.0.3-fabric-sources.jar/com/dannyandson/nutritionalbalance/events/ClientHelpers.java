package com.dannyandson.nutritionalbalance.events;

import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public class ClientHelpers {

    public static void showStatusToast(String statusName) {
        class_310.method_1551().method_1566().method_1999(
                new net.minecraft.class_370(
                        net.minecraft.class_370.class_371.field_36445,
                        class_2561.method_43471("nutritionalbalance.nutrientstatus." + statusName),
                        class_2561.method_43471("nutritionalbalance.nutrientstatus.msg." + statusName)
                )
        );
    }

    public static class_1657 getLocalPlayer() {
        return class_310.method_1551().field_1724;
    }
}