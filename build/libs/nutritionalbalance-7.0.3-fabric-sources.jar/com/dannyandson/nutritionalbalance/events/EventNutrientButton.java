package com.dannyandson.nutritionalbalance.events;

import com.dannyandson.nutritionalbalance.Config;
import com.dannyandson.nutritionalbalance.gui.NutrientButton;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_2561;
import net.minecraft.class_490;

public class EventNutrientButton {

    public static void init() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof class_490 gui && Config.NUTRIENT_BUTTON_ENABLED.get()) {
                Screens.getButtons(gui).add(
                        new NutrientButton(gui, class_2561.method_43473())
                );
            }
        });
    }
}