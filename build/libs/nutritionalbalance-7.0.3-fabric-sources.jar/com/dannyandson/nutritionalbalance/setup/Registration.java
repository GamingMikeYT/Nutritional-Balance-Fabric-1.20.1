package com.dannyandson.nutritionalbalance.setup;

import com.dannyandson.nutritionalbalance.NutritionalBalance;
import com.dannyandson.nutritionalbalance.effects.ModMobAffects;
import com.dannyandson.nutritionalbalance.lunchbox.LunchBoxItem;
import com.dannyandson.nutritionalbalance.lunchbox.LunchBoxMenu;
import net.minecraft.class_1291;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7701;
import net.minecraft.class_7923;

public class Registration {

    public static final class_1291 ENGORGED_EFFECT =
            class_2378.method_10230(
                    class_7923.field_41174,
                    class_2960.method_43902(NutritionalBalance.MODID, "engorged_effect"),
                    new ModMobAffects.Engorged()
            );

    public static final class_1291 MALNOURISHED_EFFECT =
            class_2378.method_10230(
                    class_7923.field_41174,
                    class_2960.method_43902(NutritionalBalance.MODID, "malnourished_effect"),
                    new ModMobAffects.MalNourished()
            );

    public static final class_1291 NOURISHED_EFFECT =
            class_2378.method_10230(
                    class_7923.field_41174,
                    class_2960.method_43902(NutritionalBalance.MODID, "nourished_effect"),
                    new ModMobAffects.Nourished()
            );

    public static final class_3917<LunchBoxMenu> LUNCHBOX_MENU_TYPE =
            class_2378.method_10230(
                    class_7923.field_41187,
                    class_2960.method_43902(NutritionalBalance.MODID, "lunchbbox"),
                    new class_3917<>(
                            LunchBoxMenu::createMenu,
                            class_7701.field_40182
                    )
            );

    public static final class_1792 LUNCHBOX_ITEM =
            class_2378.method_10230(
                    class_7923.field_41178,
                    class_2960.method_43902(NutritionalBalance.MODID, "lunchbox"),
                    new LunchBoxItem()
            );

    public static void register() {
        // Registration happens when the static fields above are initialized.
    }
}