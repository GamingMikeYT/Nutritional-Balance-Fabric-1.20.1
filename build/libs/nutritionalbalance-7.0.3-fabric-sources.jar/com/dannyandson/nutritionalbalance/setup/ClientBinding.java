package com.dannyandson.nutritionalbalance.setup;

import com.dannyandson.nutritionalbalance.Config;
import com.dannyandson.nutritionalbalance.lunchbox.LunchBoxItem;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_310;

public class ClientBinding {

    public static boolean wheelEvent(double scrollDeltaY) {

        if (scrollDeltaY == 0) {
            return false;
        }

        class_1657 player = class_310.method_1551().field_1724;

        if (
                player != null
                        && player.method_5715()
                        && player.method_6047().method_7909()
                        instanceof LunchBoxItem lunchBoxItem
        ) {
            class_1799 lunchBoxStack = player.method_6047();

            Integer activeSlot =
                    lunchBoxItem.getActiveFoodItemSlot(lunchBoxStack);

            Integer maxSlot = null;

            for (
                    int i = 0;
                    i < Config.LUNCHBOX_SLOT_COUNT.get();
                    i++
            ) {
                class_1799 stack =
                        lunchBoxItem.getItemStack(
                                lunchBoxStack,
                                i
                        );

                if (
                        stack != null
                                && stack != class_1799.field_8037
                ) {
                    maxSlot = i;
                }
            }

            if (maxSlot != null) {

                boolean reverse = scrollDeltaY < 0;

                class_1799 activeStack;

                if (activeSlot == null) {

                    activeStack =
                            lunchBoxItem.getItemStack(
                                    lunchBoxStack,
                                    reverse ? maxSlot : 0
                            );

                } else {

                    activeSlot += reverse ? -1 : 1;

                    if (activeSlot > maxSlot) {
                        activeSlot = 0;
                    }

                    if (activeSlot < 0) {
                        activeSlot = maxSlot;
                    }

                    activeStack =
                            lunchBoxItem.getItemStack(
                                    lunchBoxStack,
                                    activeSlot
                            );
                }

                if (activeStack != null) {
                    lunchBoxItem.setActiveFood(
                            lunchBoxStack,
                            activeStack,
                            true
                    );
                }
            }

            return true;
        }

        return false;
    }
}