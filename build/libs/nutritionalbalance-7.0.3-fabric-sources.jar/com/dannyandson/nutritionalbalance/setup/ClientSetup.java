package com.dannyandson.nutritionalbalance.setup;

import com.dannyandson.nutritionalbalance.events.EventNutrientButton;
import com.dannyandson.nutritionalbalance.lunchbox.LunchBoxItemRenderer;
import com.dannyandson.nutritionalbalance.lunchbox.LunchBoxScreen;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_3929;
import net.minecraft.class_7706;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;

public class ClientSetup {

    public static void init() {

        // Register the nutrient button on the inventory screen
        EventNutrientButton.init();

        // Register the lunchbox screen
        class_3929.method_17542(
                Registration.LUNCHBOX_MENU_TYPE,
                LunchBoxScreen::new
        );

        // Add the lunchbox to the Food & Drink creative tab
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41061)
                .register(entries -> entries.method_45421(Registration.LUNCHBOX_ITEM));

        // Register the lunchbox's custom 3D renderer
        BuiltinItemRendererRegistry.INSTANCE.register(
                Registration.LUNCHBOX_ITEM,
                new LunchBoxItemRenderer()
        );

        // Load the lunchbox 3D model
        ModelLoadingPlugin.register(context -> {
            context.addModels(LunchBoxItemRenderer.LUNCHBOX_3D_MODEL);
        });
    }
}