package com.dannyandson.nutritionalbalance.nutrients;

import com.dannyandson.nutritionalbalance.Config;
import com.dannyandson.nutritionalbalance.NutritionalBalance;
import com.dannyandson.nutritionalbalance.lunchbox.LunchBoxItem;
import com.dannyandson.nutritionalbalance.network.ModNetworkHandler;
import com.dannyandson.nutritionalbalance.network.NutrientDataSyncTrigger;
import java.util.*;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.minecraft.class_4174;
import net.minecraft.class_6862;
import net.minecraft.class_7923;

public class WorldNutrients {

    private static final List<Nutrient> nutrients = new ArrayList<>();
    private static final Map<class_1792, List<Nutrient>> nutrientMap = new HashMap<>();

    private static Map<class_1792, List<class_1860<?>>> recipesByOutput = null;
    private static class_1863 indexedRecipeManager = null;

    private static final Set<class_1792> resolving = new HashSet<>();
    private static final Set<class_1792> pendingClientSyncs = new HashSet<>();

    private static boolean prewarmComplete = false;
    private static boolean nutrientsRegistered = false;

    public static void register() {
        reset();

        // Discover nutrient definitions supplied by datapacks or mods.
        for (class_6862<class_1792> tagKey : class_7923.field_41178.method_40273()
                .sorted((a, b) ->
                        a.comp_327().method_12832().compareTo(b.comp_327().method_12832()))
                .toList()) {

            class_2960 id = tagKey.comp_327();

            if (id.method_12836().equals("c")
                    && id.method_12832().startsWith("nutrients/")) {

                addNutrient(id.method_12832().substring("nutrients/".length()));
            }
        }

        // Ensure the default configuration categories exist.
        addNutrient("fruits");
        addNutrient("proteins");
        addNutrient("carbs");
        addNutrient("vegetables");
        addNutrient("sugars");

        nutrientsRegistered = true;

        NutritionalBalance.LOGGER.info(
                "Nutritional Balance: registered nutrients: {}",
                nutrients.stream().map(n -> n.name).toList()
        );
    }

    private static void addNutrient(String name) {
        for (Nutrient nutrient : nutrients) {
            if (nutrient.name.equals(name)) {
                return;
            }
        }

        nutrients.add(new Nutrient(name));
    }

    public static List<Nutrient> get() {
        if (!nutrientsRegistered) {
            register();
        }

        return nutrients;
    }

    public static Nutrient getByName(String name) {
        for (Nutrient nutrient : get()) {
            if (nutrient.name.equals(name)) {
                return nutrient;
            }
        }

        return null;
    }

    public static List<Nutrient> getNutrients(class_1792 item, class_1937 world) {
        return getNutrients(item.method_7854(), world, 1);
    }

    public static List<Nutrient> getNutrients(class_1799 itemStack, class_1937 world) {
        return getNutrients(itemStack, world, 1);
    }

    private static List<Nutrient> getNutrients(
            class_1799 item,
            class_1937 world,
            int iteration
    ) {
        if (item.method_7909() instanceof LunchBoxItem lunchBoxItem) {
            item = lunchBoxItem.getActiveFoodItemStack(item);
        }

        if (item == null || item.method_7960()) {
            return new ArrayList<>();
        }

        class_1792 targetItem = item.method_7909();

        if (class_7923.field_41178.method_10221(targetItem).toString().equals("minecraft:bread")) {
            NutritionalBalance.LOGGER.info(
                    "[Nutrient Debug] Bread cache status: containsKey={}, cached nutrients={}",
                    nutrientMap.containsKey(targetItem),
                    nutrientMap.containsKey(targetItem)
                            ? nutrientMap.get(targetItem).stream().map(n -> n.name).toList()
                            : "NOT CACHED"
            );
        }

        if (!nutrientMap.containsKey(targetItem)) {

            if (world != null && world.method_8608()) {
                if (pendingClientSyncs.add(targetItem)) {
                    ModNetworkHandler.sendToServer(
                            new NutrientDataSyncTrigger(targetItem)
                    );
                }

            } else if (world != null) {

                List<Nutrient> nutrientList = new ArrayList<>();

                class_2960 debugItemId = class_7923.field_41178.method_10221(targetItem);
                boolean debugItem =
                        debugItemId != null
                                && (debugItemId.toString().equals("minecraft:apple")
                                || debugItemId.toString().equals("minecraft:bread"));

                if (debugItem) {
                    NutritionalBalance.LOGGER.info(
                            "[Nutrient Debug] Checking item: {}",
                            debugItemId
                    );

                    NutritionalBalance.LOGGER.info(
                            "[Nutrient Debug] Item tags: {}",
                            item.method_40133()
                                    .map(tag -> "#" + tag.comp_327().method_12836()
                                            + ":" + tag.comp_327().method_12832())
                                    .sorted()
                                    .toList()
                    );

                    NutritionalBalance.LOGGER.info(
                            "[Nutrient Debug] Fruit config: {}",
                            Config.LIST_Fruits.get()
                    );


                    NutritionalBalance.LOGGER.info(
                            "[Nutrient Debug] Carb config: {}",
                            Config.LIST_CARBS.get()
                    );

                    NutritionalBalance.LOGGER.info(
                            "[Nutrient Debug] Bread tag configured: {}",
                            Config.LIST_CARBS.get().contains("#c:bread/wheat")
                    );

                    NutritionalBalance.LOGGER.info(
                            "[Nutrient Debug] Bread tag present on item: {}",
                            item.method_40133().anyMatch(tag ->
                                    tag.comp_327().toString().equals("c:bread/wheat"))
                    );

                    NutritionalBalance.LOGGER.info(
                            "[Nutrient Debug] Vegetable config: {}",
                            Config.LIST_VEGETABLES.get()
                    );

                    NutritionalBalance.LOGGER.info(
                            "[Nutrient Debug] Protein config: {}",
                            Config.LIST_PROTEINS.get()
                    );

                    NutritionalBalance.LOGGER.info(
                            "[Nutrient Debug] Sugar config: {}",
                            Config.LIST_SUGARS.get()
                    );
                }

                // Match the item's tags against configured category tags.
                for (class_6862<class_1792> tagKey : item.method_40133()
                        .sorted((a, b) ->
                                a.comp_327().method_12832().compareTo(b.comp_327().method_12832()))
                        .toList()) {

                    class_2960 tag = tagKey.comp_327();
                    String tagName =
                            "#" + tag.method_12836() + ":" + tag.method_12832();

                    if (Config.LIST_Fruits.get().contains(tagName)) {
                        addIfPresent(nutrientList, "fruits");
                    }

                    if (Config.LIST_PROTEINS.get().contains(tagName)) {
                        addIfPresent(nutrientList, "proteins");
                    }

                    if (Config.LIST_CARBS.get().contains(tagName)) {
                        addIfPresent(nutrientList, "carbs");
                    }

                    if (Config.LIST_VEGETABLES.get().contains(tagName)) {
                        addIfPresent(nutrientList, "vegetables");
                    }

                    if (Config.LIST_SUGARS.get().contains(tagName)) {
                        addIfPresent(nutrientList, "sugars");
                    }

                    if (tag.method_12836().equals("c")
                            && tag.method_12832().startsWith("nutrients/")) {
                        addIfPresent(
                                nutrientList,
                                tag.method_12832().substring("nutrients/".length())
                        );
                    }
                }

                // Match explicit item IDs in the config.
                class_2960 itemId = class_7923.field_41178.method_10221(targetItem);
                String itemRegistryName =
                        itemId.method_12836() + ":" + itemId.method_12832();

                if (Config.LIST_CARBS.get().contains(itemRegistryName)) {
                    addIfPresent(nutrientList, "carbs");
                }

                if (Config.LIST_Fruits.get().contains(itemRegistryName)) {
                    addIfPresent(nutrientList, "fruits");
                }

                if (Config.LIST_PROTEINS.get().contains(itemRegistryName)) {
                    addIfPresent(nutrientList, "proteins");
                }

                if (Config.LIST_SUGARS.get().contains(itemRegistryName)) {
                    addIfPresent(nutrientList, "sugars");
                }

                if (Config.LIST_VEGETABLES.get().contains(itemRegistryName)) {
                    addIfPresent(nutrientList, "vegetables");
                }

                if (debugItem) {
                    NutritionalBalance.LOGGER.info(
                            "[Nutrient Debug] After direct tag/config matching for {}: {}",
                            debugItemId,
                            nutrientList.stream().map(n -> n.name).toList()
                    );
                }

                boolean depthLimited = false;

                if (nutrientList.isEmpty() && iteration < 5) {
                    boolean isMeat = false;

                    for (class_6862<class_1792> tagKey : item.method_40133().toList()) {
                        String path = tagKey.comp_327().method_12832();
                        String namespace = tagKey.comp_327().method_12836();

                        if ((namespace.equals("c")
                                && (path.contains("meat")
                                || path.contains("raw_meat")))
                                || (namespace.equals("minecraft")
                                && path.equals("meat"))) {
                            isMeat = true;
                            break;
                        }
                    }

                    if (isMeat) {
                        addIfPresent(nutrientList, "proteins");

                    } else if (resolving.add(targetItem)) {
                        try {
                            for (class_1860<?> recipe :
                                    getRecipesForOutput(world, targetItem)) {

                                class_2371<class_1856> ingredients =
                                        recipe.method_8117();

                                // Inspect every matching item in each ingredient.
                                for (class_1856 ingredient : ingredients) {
                                    class_1799[] matchingStacks =
                                            ingredient.method_8105();

                                    for (class_1799 matchingStack : matchingStacks) {
                                        if (matchingStack.method_7960()) {
                                            continue;
                                        }

                                        List<Nutrient> inherited =
                                                getNutrients(
                                                        matchingStack,
                                                        world,
                                                        iteration + 1
                                                );

                                        for (Nutrient nutrient : inherited) {
                                            if (!nutrientList.contains(nutrient)) {
                                                nutrientList.add(nutrient);
                                            }
                                        }
                                    }
                                }
                            }
                        } finally {
                            resolving.remove(targetItem);
                        }

                    } else {
                        depthLimited = true;
                    }
                }

                if (debugItem) {
                    NutritionalBalance.LOGGER.info(
                            "[Nutrient Debug] Final nutrients for {}: {} (iteration={})",
                            debugItemId,
                            nutrientList.stream().map(n -> n.name).toList(),
                            iteration
                    );
                }

                if (!depthLimited) {
                    if (class_7923.field_41178.method_10221(targetItem).toString().equals("minecraft:bread")) {
                        NutritionalBalance.LOGGER.info(
                                "[Nutrient Debug] CACHING bread nutrients: {}",
                                nutrientList.stream().map(n -> n.name).toList()
                        );
                    }
                    nutrientMap.put(targetItem, nutrientList);
                } else {
                    return nutrientList;
                }
            }
        }

        return nutrientMap.containsKey(targetItem)
                ? nutrientMap.get(targetItem)
                : new ArrayList<>();
    }

    private static void addIfPresent(
            List<Nutrient> target,
            String name
    ) {
        Nutrient nutrient = getByName(name);

        if (nutrient != null && !target.contains(nutrient)) {
            target.add(nutrient);
        }
    }

    private static List<class_1860<?>> getRecipesForOutput(
            class_1937 world,
            class_1792 item
    ) {
        class_1863 rm = world.method_8433();

        if (recipesByOutput == null || indexedRecipeManager != rm) {
            buildRecipeIndex(world, rm);
        }

        List<class_1860<?>> bucket = recipesByOutput.get(item);

        return bucket != null ? bucket : Collections.emptyList();
    }

    private static void buildRecipeIndex(
            class_1937 world,
            class_1863 rm
    ) {
        long start = System.currentTimeMillis();
        Map<class_1792, List<class_1860<?>>> idx = new HashMap<>();

        for (class_1860<?> recipe : rm.method_8126()) {
            try {
                class_1799 output =
                        recipe.method_8110(world.method_30349());

                if (output != null && !output.method_7960()) {
                    idx.computeIfAbsent(
                            output.method_7909(),
                            key -> new ArrayList<>()
                    ).add(recipe);
                }
            } catch (Throwable t) {
                // Skip recipes whose outputs cannot be queried.
            }
        }

        for (List<class_1860<?>> bucket : idx.values()) {
            bucket.sort((a, b) ->
                    b.method_8114().method_12832().compareTo(a.method_8114().method_12832()));
        }

        recipesByOutput = idx;
        indexedRecipeManager = rm;

        NutritionalBalance.LOGGER.info(
                "Nutritional Balance: built recipe-output index ({} output items, {} ms)",
                idx.size(),
                System.currentTimeMillis() - start
        );
    }

    public static void prewarm(class_1937 world) {
        if (prewarmComplete || world == null) {
            return;
        }

        long start = System.currentTimeMillis();
        int considered = 0;
        int succeeded = 0;

        for (class_1792 item : class_7923.field_41178) {
            try {
                class_4174 food = item.method_19264();

                if (food != null) {
                    considered++;
                    getNutrients(item, world);
                    succeeded++;
                }
            } catch (Throwable t) {
                NutritionalBalance.LOGGER.debug(
                        "Nutritional Balance: failed to prewarm nutrients for {}",
                        class_7923.field_41178.method_10221(item),
                        t
                );
            }
        }

        prewarmComplete = true;

        NutritionalBalance.LOGGER.info(
                "Nutritional Balance: pre-warmed nutrient cache for {}/{} food items in {} ms",
                succeeded,
                considered,
                System.currentTimeMillis() - start
        );
    }

    public static Map<class_2960, List<String>> snapshotForSync() {
        Map<class_2960, List<String>> snapshot =
                new HashMap<>(nutrientMap.size());

        for (Map.Entry<class_1792, List<Nutrient>> entry : nutrientMap.entrySet()) {
            class_2960 itemId = class_7923.field_41178.method_10221(entry.getKey());

            if (itemId == null) {
                continue;
            }

            List<String> names = new ArrayList<>(entry.getValue().size());

            for (Nutrient nutrient : entry.getValue()) {
                names.add(nutrient.name);
            }

            snapshot.put(itemId, names);
        }

        return snapshot;
    }

    public static void applyBulkSync(Map<class_2960, List<String>> data) {
        int applied = 0;

        for (Map.Entry<class_2960, List<String>> entry : data.entrySet()) {
            class_2960 key = entry.getKey();

            if (!class_7923.field_41178.method_10250(key)) {
                continue;
            }

            class_1792 item = class_7923.field_41178.method_10223(key);

            if (item == null) {
                continue;
            }

            List<Nutrient> nuts = new ArrayList<>(entry.getValue().size());

            for (String name : entry.getValue()) {
                if (name.isEmpty()) {
                    continue;
                }

                Nutrient nutrient = getByName(name);

                if (nutrient != null) {
                    nuts.add(nutrient);
                }
            }

            nutrientMap.put(item, nuts);
            pendingClientSyncs.remove(item);
            applied++;
        }

        NutritionalBalance.LOGGER.info(
                "Nutritional Balance: applied bulk nutrient sync for {} items",
                applied
        );
    }


    public static float getEffectiveFoodQuality(
            class_4174 foodItem,
            int numberOfNutrients
    ) {
        float actualSaturation = foodItem.method_19230()
                * foodItem.method_19231()
                * 2.0F;

        return getEffectiveFoodQuality(
                foodItem.method_19230(),
                actualSaturation,
                numberOfNutrients
        );
    }


    public static float getEffectiveFoodQuality(
            float healing,
            float saturation,
            int numberOfNutrients
    ) {
        return Math.min(
                healing + saturation,
                Config.NUTRIENT_MAX_FOOD_VALUE.get().floatValue()
                        * numberOfNutrients
        );
    }

    public static void setItemNutrients(class_1792 item, List<Nutrient> nutrients) {
        nutrientMap.put(item, nutrients);
        pendingClientSyncs.remove(item);
    }

    public static void reset() {
        nutrients.clear();
        nutrientMap.clear();

        recipesByOutput = null;
        indexedRecipeManager = null;

        resolving.clear();
        pendingClientSyncs.clear();

        prewarmComplete = false;
        nutrientsRegistered = false;
    }
}
