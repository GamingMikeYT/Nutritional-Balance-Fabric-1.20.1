package com.dannyandson.nutritionalbalance.nutrients;

import net.minecraft.class_1074;

public class Nutrient {

    public String name;

    public Nutrient(String name) {
        this.name = name;
    }

    public String getLocalizedName() {
        return class_1074.method_4662(
                "nutritionalbalance.nutrient." + this.name,
                new Object[0]
        );
    }
}