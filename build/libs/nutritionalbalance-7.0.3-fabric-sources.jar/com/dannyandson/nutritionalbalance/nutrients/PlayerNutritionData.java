package com.dannyandson.nutritionalbalance.nutrients;

import com.dannyandson.nutritionalbalance.NutritionalBalance;
import com.dannyandson.nutritionalbalance.api.INutritionalBalancePlayer;
import com.dannyandson.nutritionalbalance.api.IPlayerNutrient;
import com.dannyandson.nutritionalbalance.capabilities.DefaultNutritionalBalancePlayer;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1657;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_26;
import net.minecraft.class_3218;

public class PlayerNutritionData extends class_18 {

    private static PlayerNutritionData worldNutritionData;

    public static void init(class_3218 serverWorld) {
        class_26 stateManager =
                serverWorld.method_17983();

        worldNutritionData = stateManager.method_17924(
                PlayerNutritionData::load,
                PlayerNutritionData::new,
                NutritionalBalance.MODID
        );

        worldNutritionData.method_80();
    }

    public static PlayerNutritionData getWorldNutritionData() {
        if (worldNutritionData == null) {
            worldNutritionData = new PlayerNutritionData();
        }

        return worldNutritionData;
    }

    Map<String, INutritionalBalancePlayer> playerUUIDDataMap =
            new HashMap<>();

    PlayerNutritionData() {
    }

    public static PlayerNutritionData load(class_2487 nbt) {
        PlayerNutritionData data =
                new PlayerNutritionData();

        for (String uuid : nbt.method_10541()) {

            DefaultNutritionalBalancePlayer nutritionalBalancePlayer =
                    new DefaultNutritionalBalancePlayer();

            class_2487 playerNBT =
                    nbt.method_10562(uuid);

            for (Nutrient nutrient : WorldNutrients.get()) {

                nutritionalBalancePlayer
                        .getPlayerNutrientByName(nutrient.name)
                        .setValue(
                                playerNBT.method_10583(nutrient.name)
                        );
            }

            data.playerUUIDDataMap.put(
                    uuid,
                    nutritionalBalancePlayer
            );
        }

        return data;
    }

    @Override
    public class_2487 method_75(
            class_2487 nbt
    ) {
        for (
                Map.Entry<String, INutritionalBalancePlayer> entry :
                playerUUIDDataMap.entrySet()
        ) {

            class_2487 playerNBT =
                    new class_2487();

            for (
                    IPlayerNutrient playerNutrient :
                    entry.getValue().getPlayerNutrients()
            ) {

                playerNBT.method_10548(
                        playerNutrient.getNutrient().name,
                        playerNutrient.getValue()
                );
            }

            nbt.method_10566(
                    entry.getKey(),
                    playerNBT
            );
        }

        return nbt;
    }

    public INutritionalBalancePlayer getNutritionalBalancePlayer(
            class_1657 player
    ) {
        String uuid =
                player.method_5845();

        if (!playerUUIDDataMap.containsKey(uuid)) {
            playerUUIDDataMap.put(
                    uuid,
                    new DefaultNutritionalBalancePlayer()
            );

            method_80();
        }

        return playerUUIDDataMap.get(uuid);
    }

    public void setDirty() {
        method_80();
    }
}