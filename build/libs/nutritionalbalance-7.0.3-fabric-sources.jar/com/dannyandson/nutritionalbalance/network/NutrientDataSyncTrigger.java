package com.dannyandson.nutritionalbalance.network;

import com.dannyandson.nutritionalbalance.NutritionalBalance;
import com.dannyandson.nutritionalbalance.nutrients.WorldNutrients;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public record NutrientDataSyncTrigger(net.minecraft.class_1792 item) {

    public static final class_2960 ID =
            new class_2960(
                    NutritionalBalance.MODID,
                    "nutrient_sync_trigger"
            );

    public static NutrientDataSyncTrigger decode(
            net.minecraft.class_2540 buf
    ) {
        class_1799 stack = buf.method_10819();

        return new NutrientDataSyncTrigger(stack.method_7909());
    }

    public static void encode(
            net.minecraft.class_2540 buf,
            NutrientDataSyncTrigger packet
    ) {
        buf.method_10793(packet.item().method_7854());
    }

    public static void handle(
            NutrientDataSyncTrigger packet,
            class_3222 player
    ) {
        ModNetworkHandler.sendToClient(
                new NutrientDataSync(
                        packet.item(),
                        WorldNutrients.getNutrients(
                                packet.item(),
                                player.method_37908()
                        )
                ),
                player
        );
    }
}