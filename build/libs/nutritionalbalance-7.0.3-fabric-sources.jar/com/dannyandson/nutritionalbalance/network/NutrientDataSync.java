
package com.dannyandson.nutritionalbalance.network;

import com.dannyandson.nutritionalbalance.NutritionalBalance;
import com.dannyandson.nutritionalbalance.nutrients.Nutrient;
import com.dannyandson.nutritionalbalance.nutrients.WorldNutrients;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public record NutrientDataSync(
        net.minecraft.class_1792 item,
        List<Nutrient> nutrients
) {

    public static final class_2960 ID =
            new class_2960(
                    NutritionalBalance.MODID,
                    "nutrient_data_sync"
            );

    public static NutrientDataSync decode(
            net.minecraft.class_2540 buf
    ) {
        class_1799 stack = buf.method_10819();
        net.minecraft.class_1792 item = stack.method_7909();

        List<Nutrient> nutrients = new ArrayList<>();

        String[] nutrientStrings = buf.method_19772().split(",");

        for (String nutrientString : nutrientStrings) {
            Nutrient nutrient =
                    WorldNutrients.getByName(nutrientString);

            if (nutrient != null) {
                nutrients.add(nutrient);
            }
        }

        return new NutrientDataSync(item, nutrients);
    }

    public static void encode(
            net.minecraft.class_2540 buf,
            NutrientDataSync packet
    ) {
        buf.method_10793(packet.item().method_7854());

        StringBuilder nutrientString = new StringBuilder();

        for (Nutrient nutrient : packet.nutrients()) {
            if (nutrientString.length() > 0) {
                nutrientString.append(",");
            }

            nutrientString.append(nutrient.name);
        }

        buf.method_10814(nutrientString.toString());
    }

    public static void handle(NutrientDataSync packet) {
        NutritionalBalance.LOGGER.info(
                "[Nutrient Sync Debug] Received {} with nutrients: {}",
                class_7923.field_41178.method_10221(packet.item()),
                packet.nutrients().stream()
                        .map(nutrient -> nutrient.name)
                        .toList()
        );

        WorldNutrients.setItemNutrients(
                packet.item(),
                packet.nutrients()
        );
    }
}