package com.dannyandson.nutritionalbalance.network;

import com.dannyandson.nutritionalbalance.NutritionalBalance;
import com.dannyandson.nutritionalbalance.nutrients.WorldNutrients;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

/**
 * One-shot packet sent from the server to a client to populate the entire local nutrient cache, so the
 * client never needs to round-trip per-item NutrientDataSyncTrigger requests during JEI/REI/EMI tooltip
 * indexing or general inventory hovering. Sent on player join and re-broadcast after datapack reloads.
 *
 * Wire format: VarInt count, then for each entry: Identifier (item id) + String (comma-separated
 * nutrient names; empty string means "this item is known to have no nutrients").
 */
public record NutrientDataBulkSync(
        Map<class_2960, List<String>> data
) {

    public static final class_2960 ID =
            new class_2960(
                    NutritionalBalance.MODID,
                    "nutrient_data_bulk_sync"
            );

    public static NutrientDataBulkSync decode(class_2540 buf) {
        int count = buf.method_10816();

        Map<class_2960, List<String>> data =
                new HashMap<>(count);

        for (int i = 0; i < count; i++) {
            class_2960 key = buf.method_10810();
            String csv = buf.method_19772();

            List<String> values =
                    csv.isEmpty()
                            ? new ArrayList<>()
                            : new ArrayList<>(Arrays.asList(csv.split(",")));

            data.put(key, values);
        }

        return new NutrientDataBulkSync(data);
    }

    public static void encode(
            class_2540 buf,
            NutrientDataBulkSync packet
    ) {
        buf.method_10804(packet.data().size());

        for (Map.Entry<class_2960, List<String>> entry :
                packet.data().entrySet()) {

            buf.method_10812(entry.getKey());
            buf.method_10814(String.join(",", entry.getValue()));
        }
    }

    public static void handle(NutrientDataBulkSync packet) {
        WorldNutrients.applyBulkSync(packet.data());
    }
}