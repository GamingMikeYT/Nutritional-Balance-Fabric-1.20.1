package com.dannyandson.nutritionalbalance.network;

import com.dannyandson.nutritionalbalance.NutritionalBalance;
import com.dannyandson.nutritionalbalance.lunchbox.LunchBoxItem;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public record LunchBoxActiveItemSync(String activeItemId) {

    public static final class_2960 ID =
            new class_2960(
                    NutritionalBalance.MODID,
                    "lunchbox_active"
            );

    public static LunchBoxActiveItemSync decode(class_2540 buf) {
        return new LunchBoxActiveItemSync(
                buf.method_19772()
        );
    }

    public void encode(class_2540 buf) {
        buf.method_10814(activeItemId);
    }

    public static void handle(
            LunchBoxActiveItemSync packet,
            class_3222 player
    ) {
        class_1799 stack = player.method_6047();

        if (stack.method_7909() instanceof LunchBoxItem lunchBoxItem) {
            lunchBoxItem.setActiveFood(
                    stack,
                    packet.activeItemId()
            );
        }
    }
}