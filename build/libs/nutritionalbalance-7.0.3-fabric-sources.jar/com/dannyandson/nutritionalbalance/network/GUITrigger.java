package com.dannyandson.nutritionalbalance.network;

import com.dannyandson.nutritionalbalance.NutritionalBalance;
import com.dannyandson.nutritionalbalance.api.INutritionalBalancePlayer;
import com.dannyandson.nutritionalbalance.nutrients.PlayerNutritionData;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class GUITrigger {

    public static final class_2960 ID =
            new class_2960(
                    NutritionalBalance.MODID,
                    "gui_trigger"
            );

    public static void handle(class_3222 player) {
        INutritionalBalancePlayer inutritionalbalancePlayer =
                PlayerNutritionData.getWorldNutritionData()
                        .getNutritionalBalancePlayer(player);

        ModNetworkHandler.sendToClient(
                new PlayerSync(inutritionalbalancePlayer, true),
                player
        );
    }
}