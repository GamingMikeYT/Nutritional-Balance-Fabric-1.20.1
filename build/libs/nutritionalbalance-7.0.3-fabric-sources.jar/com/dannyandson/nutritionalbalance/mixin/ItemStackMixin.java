
package com.dannyandson.nutritionalbalance.mixin;

import com.dannyandson.nutritionalbalance.events.EventUseItem;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1799.class)
public class ItemStackMixin {

    @Inject(method = "finishUsing", at = @At("HEAD"))
    private void nutritionalbalance$onUseItemFinish(
            class_1937 world,
            class_1309 user,
            CallbackInfoReturnable<class_1799> cir
    ) {
        class_1799 originalStack = (class_1799) (Object) this;

        System.out.println(
                "[Nutrient Debug] finishUsing called: item="
                        + originalStack.method_7909()
                        + ", client=" + world.field_9236
                        + ", user=" + user.getClass().getSimpleName()
        );

        if (!world.field_9236 && user instanceof class_3222 player) {
            System.out.println(
                    "[Nutrient Debug] Server food finishUsing callback fired"
            );

            EventUseItem.onUseItemFinish(originalStack, world, player);
        }
    }
}
