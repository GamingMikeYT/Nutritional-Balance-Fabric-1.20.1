package com.dannyandson.nutritionalbalance.lunchbox;

import com.dannyandson.nutritionalbalance.Config;
import com.dannyandson.nutritionalbalance.setup.Registration;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import org.jetbrains.annotations.NotNull;

public class LunchBoxMenu extends class_1703 {

    public static @NotNull LunchBoxMenu createMenu(
            int containerId,
            class_1661 playerInventory
    ) {
        return createMenu(
                containerId,
                playerInventory,
                LunchBoxContainer.get(
                        Registration.LUNCHBOX_ITEM.method_7854()
                )
        );
    }

    public static LunchBoxMenu createMenu(
            int containerId,
            class_1661 playerInventory,
            class_1263 inventory
    ) {
        return new LunchBoxMenu(containerId, playerInventory, inventory);
    }

    private class_1263 container;
    private class_1661 playerInventory;
    private class_1799 lunchBox;

    protected LunchBoxMenu(
            int containerId,
            class_1661 playerInventory,
            class_1263 container
    ) {
        super(Registration.LUNCHBOX_MENU_TYPE, containerId);

        method_17359(container, Config.LUNCHBOX_SLOT_COUNT.get());

        this.container = container;
        this.playerInventory = playerInventory;
        this.lunchBox = playerInventory.method_7391();

        int leftCol = 47;
        int ySize = 252;

        container.method_5435(playerInventory.field_7546);

        for (
                int lunchBoxRow = 0;
                lunchBoxRow < container.method_5439();
                lunchBoxRow++
        ) {
            this.method_7621(
                    new class_1735(
                            container,
                            lunchBoxRow,
                            leftCol + lunchBoxRow * 18,
                            ySize - 6 * 18 - 10
                    ) {
                        @Override
                        public void method_7668() {
                            method_7609(container);
                            super.method_7668();
                        }

                        @Override
                        public boolean method_7680(class_1799 stack) {
                            return stack.method_7909().method_19264() != null
                                    && !(stack.method_7909() instanceof LunchBoxItem);
                        }
                    }
            );
        }

        for (int playerInvRow = 0; playerInvRow < 3; playerInvRow++) {
            for (int playerInvCol = 0; playerInvCol < 9; playerInvCol++) {
                this.method_7621(
                        new class_1735(
                                playerInventory,
                                playerInvCol + playerInvRow * 9 + 9,
                                leftCol + playerInvCol * 18,
                                ySize - (4 - playerInvRow) * 18 - 10
                        )
                );
            }
        }

        for (int hotbarSlot = 0; hotbarSlot < 9; hotbarSlot++) {
            this.method_7621(
                    new class_1735(
                            playerInventory,
                            hotbarSlot,
                            leftCol + hotbarSlot * 18,
                            ySize - 24
                    )
            );
        }
    }

    @Override
    public @NotNull class_1799 method_7601(
            class_1657 player,
            int index
    ) {
        class_1799 itemstack = class_1799.field_8037;

        class_1735 slot = this.field_7761.get(index);

        if (slot != null && slot.method_7681()) {

            class_1799 itemstack1 = slot.method_7677();

            itemstack = itemstack1.method_7972();

            if (index < Config.LUNCHBOX_SLOT_COUNT.get()) {

                if (
                        !this.method_7616(
                                itemstack1,
                                Config.LUNCHBOX_SLOT_COUNT.get(),
                                this.field_7761.size(),
                                true
                        )
                ) {
                    return class_1799.field_8037;
                }

            } else if (
                    !this.method_7616(
                            itemstack1,
                            0,
                            Config.LUNCHBOX_SLOT_COUNT.get(),
                            false
                    )
            ) {
                return class_1799.field_8037;
            }

            if (itemstack1.method_7960()) {
                slot.method_48931(class_1799.field_8037);
            } else {
                slot.method_7668();
            }
        }

        return itemstack;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return this.container.method_5443(player)
                && player.method_6047() == this.lunchBox;
    }

    @Override
    public void method_7609(class_1263 inventory) {
        if (this.container instanceof LunchBoxContainer lunchBoxContainer) {
            lunchBoxContainer.save();
        }

        super.method_7609(inventory);
    }

    public void setActiveSlot(int slot) {
        if (this.lunchBox.method_7909() instanceof LunchBoxItem lunchBoxItem) {

            lunchBoxItem.setActiveFood(
                    this.lunchBox,
                    container.method_5438(slot),
                    this.playerInventory.field_7546.method_37908().method_8608()
            );
        }
    }

    public class_1799 getLunchBoxItemStack() {
        return this.lunchBox;
    }
}