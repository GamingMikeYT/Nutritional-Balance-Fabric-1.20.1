package com.dannyandson.nutritionalbalance.lunchbox;

import com.dannyandson.nutritionalbalance.NutritionalBalance;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_918;

public class LunchBoxItemRenderer implements BuiltinItemRendererRegistry.DynamicItemRenderer {

    /*
     * This is the model that tells Minecraft to use this custom renderer.
     * models/item/lunchbox_3d.json
     */
    public static final class_2960 LUNCHBOX_3D_MODEL =
            class_2960.method_43902(NutritionalBalance.MODID, "item/lunchbox_3d");

    /*
     * This is the actual generated model used for the lunchbox body.
     * models/item/lunchbox.json
     */
    private static final class_2960 LUNCHBOX_BASE_MODEL =
            class_2960.method_43902(NutritionalBalance.MODID, "item/lunchbox");

    private class_1087 baseModel;

    private class_1087 getBaseModel() {
        if (baseModel == null) {
            baseModel = class_310.method_1551()
                    .method_1554()
                    .getModel(LUNCHBOX_BASE_MODEL);
        }

        return baseModel;
    }

    @Override
    public void render(
            class_1799 stack,
            class_811 mode,
            class_4587 matrices,
            class_4597 vertexConsumers,
            int light,
            int overlay
    ) {
        class_310 minecraft = class_310.method_1551();
        class_918 itemRenderer = minecraft.method_1480();

        /*
         * Render the actual lunchbox body.
         */
        class_1087 model = getBaseModel();

        matrices.method_22903();

        matrices.method_22904(0.5, 0.5, 0.5);

        itemRenderer.method_23179(
                stack,
                class_811.field_4315,
                false,
                matrices,
                vertexConsumers,
                light,
                overlay,
                model
        );

        matrices.method_22909();

        /*
         * Render the selected food item on both faces of the lunchbox.
         */
        if (stack.method_7909() instanceof LunchBoxItem lunchBoxItem) {

            class_1799 activeStack =
                    lunchBoxItem.getActiveFoodItemStack(stack);

            if (activeStack != null) {

                /*
                 * Front face
                 */
                matrices.method_22903();

                matrices.method_22904(0.5, 0.35, 0.55);
                matrices.method_22905(0.5f, 0.5f, 0.5f);

                itemRenderer.method_23178(
                        activeStack,
                        class_811.field_4319,
                        light,
                        overlay,
                        matrices,
                        vertexConsumers,
                        minecraft.field_1687,
                        0
                );

                matrices.method_22909();

                /*
                 * Back face
                 */
                matrices.method_22903();

                matrices.method_22904(0.5, 0.35, 0.45);

                matrices.method_22907(
                        class_7833.field_40716.rotationDegrees(180)
                );

                matrices.method_22905(0.5f, 0.5f, 0.5f);

                itemRenderer.method_23178(
                        activeStack,
                        class_811.field_4319,
                        light,
                        overlay,
                        matrices,
                        vertexConsumers,
                        minecraft.field_1687,
                        0
                );

                matrices.method_22909();
            }
        }
    }
}