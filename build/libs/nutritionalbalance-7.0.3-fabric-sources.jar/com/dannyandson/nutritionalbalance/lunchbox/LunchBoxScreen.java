package com.dannyandson.nutritionalbalance.lunchbox;

import com.dannyandson.nutritionalbalance.Config;
import com.dannyandson.nutritionalbalance.NutritionalBalance;
import com.dannyandson.nutritionalbalance.gui.INutrientGUIScreen;
import com.dannyandson.nutritionalbalance.gui.ModWidget;
import com.dannyandson.nutritionalbalance.gui.NutrientGUIHelper;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_465;
import org.jetbrains.annotations.NotNull;

public class LunchBoxScreen
        extends class_465<LunchBoxMenu>
        implements INutrientGUIScreen {

    public static final class_2960 GUI =
            new class_2960(
                    NutritionalBalance.MODID,
                    "textures/gui/lunchbox_gui.png"
            );

    public static final class_2960 GUI_SLOT =
            new class_2960(
                    NutritionalBalance.MODID,
                    "textures/gui/slot.png"
            );

    private final LunchBoxMenu lunchBoxMenu;
    private final ModWidget[] widgets =
            new ModWidget[Config.LUNCHBOX_SLOT_COUNT.get()];

    public LunchBoxScreen(
            LunchBoxMenu lunchBoxMenu,
            class_1661 playerInventory,
            class_2561 title
    ) {
        super(lunchBoxMenu, playerInventory, title);

        this.lunchBoxMenu = lunchBoxMenu;

        this.field_2792 = 250;
        this.field_2779 = 250;

        this.field_25270 = this.field_2800 + 156;
        this.field_25269 = this.field_2776 + 46;

        this.field_25268 = this.field_2800 + 111;
        this.field_25267 = this.field_2776 + 46;
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        NutrientGUIHelper.init(
                this,
                this.field_2792,
                this.field_2779 / 2,
                -this.field_2779 / 4
        );

        for (int i = 0; i < Config.LUNCHBOX_SLOT_COUNT.get(); i++) {
            int finalI = i;

            method_37063(
                    ModWidget.buildButton(
                            this.field_2776 + 46 + (i * 18),
                            this.field_2800 + 123,
                            18,
                            10,
                            class_2561.method_43473(),
                            button -> toggleActive(finalI)
                    )
            );

            method_37063(
                    new ModWidget(
                            this.field_2776 + 46 + (i * 18),
                            this.field_2800 + 133,
                            18,
                            18,
                            GUI_SLOT
                    )
            );
        }
    }

    @Override
    protected void method_37432() {
        super.method_37432();

        if (this.widgets[0] == null) {
            renderActiveOverlays();
        }
    }

    @Override
    public void method_25410(
            @NotNull class_310 client,
            int width,
            int height
    ) {
        super.method_25410(client, width, height);
        renderActiveOverlays();
    }

    @Override
    public void method_25394(
            @NotNull class_332 drawContext,
            int mouseX,
            int mouseY,
            float delta
    ) {
        super.method_25394(drawContext, mouseX, mouseY, delta);
        this.method_2380(drawContext, mouseX, mouseY);
    }

    @Override
    protected void method_2389(
            class_332 drawContext,
            float delta,
            int mouseX,
            int mouseY
    ) {
        int x = (this.field_22789 - this.field_2792) / 2;
        int y = (this.field_22790 - this.field_2779) / 2;

        drawContext.method_25290(
                GUI,
                x,
                y,
                0,
                0,
                this.field_2792,
                this.field_2779,
                256,
                256
        );
    }

    private void toggleActive(int slot) {
        lunchBoxMenu.setActiveSlot(slot);
        renderActiveOverlays();
    }

    private void renderActiveOverlays() {
        for (int i = 0; i < Config.LUNCHBOX_SLOT_COUNT.get(); i++) {

            if (widgets[i] != null) {
                method_37066(widgets[i]);
            }

            int color = 0xFFFFFFFF;

            String slotItem =
                    lunchBoxMenu.field_7761
                            .get(i)
                            .method_7677()
                            .method_7909()
                            .method_7876();

            if (
                    lunchBoxMenu.getLunchBoxItemStack().method_7909()
                            instanceof LunchBoxItem lunchBoxItem
            ) {
                if (
                        lunchBoxItem.getActiveFoodItemStack(
                                lunchBoxMenu.getLunchBoxItemStack()
                        ) != null
                ) {
                    if (
                            lunchBoxItem.getActiveFoodItemStack(
                                            lunchBoxMenu.getLunchBoxItemStack()
                                    )
                                    .method_7909()
                                    .method_7876()
                                    .equals(slotItem)
                    ) {
                        color = 0xFF00FF00;
                    }
                }
            }

            widgets[i] =
                    new ModWidget(
                            this.field_2776 + 47 + i * 18,
                            this.field_2800 + 124,
                            16,
                            8,
                            color
                    );

            method_37063(widgets[i]);
        }
    }

    @Override
    public int getWidth() {
        return this.field_22789;
    }

    @Override
    public int getHeight() {
        return this.field_22790;
    }

    @Override
    public class_310 getMinecraft() {
        return class_310.method_1551();
    }

    @Override
    public ModWidget addModWidget(ModWidget modWidget) {
        return method_37063(modWidget);
    }
}