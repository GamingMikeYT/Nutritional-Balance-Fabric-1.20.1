package com.dannyandson.nutritionalbalance.lunchbox;

import com.dannyandson.nutritionalbalance.network.LunchBoxActiveItemSync;
import com.dannyandson.nutritionalbalance.network.ModNetworkHandler;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_4174;
import net.minecraft.class_437;
import net.minecraft.class_747;

public class LunchBoxItem extends class_1792 {

    public LunchBoxItem() {
        super(new class_1792.class_1793().method_7889(1));
    }

    @Override
    public @Nullable class_4174 method_19264() {
        return null;
    }

    public @Nullable class_4174 getFoodProperties(
            class_1799 stack,
            @Nullable class_1309 entity
    ) {
        if (stack.method_7909() instanceof LunchBoxItem) {
            class_1799 activeStack = getActiveFoodItemStack(stack);

            if (activeStack != null)
                return activeStack.method_7909().method_19264();

            return null;
        }

        return super.method_19264();
    }

    @Override
    public class_1271<class_1799> method_7836(
            class_1937 world,
            class_1657 player,
            class_1268 hand
    ) {
        class_1799 stack = player.method_5998(hand);

        if (stack.method_7909() instanceof LunchBoxItem) {

            class_1799 activeStack = getActiveFoodItemStack(stack);

            if (activeStack != null && !player.method_5715()) {

                class_4174 activeFoodProperties =
                        activeStack.method_7909().method_19264();

                if (
                        !activeStack.method_7960()
                                && activeFoodProperties != null
                                && !player.method_7357()
                                .method_7904(activeStack.method_7909())
                                && player.method_7332(activeFoodProperties.method_19233())
                ) {
                    player.method_6019(hand);
                    return class_1271.method_22428(stack);
                } else {
                    return class_1271.method_22431(stack);
                }

            } else if (
                    !world.field_9236
                            && !(player.field_7512 instanceof LunchBoxMenu)
                            && hand == class_1268.field_5808
            ) {
                LunchBoxContainer container = LunchBoxContainer.get(stack);

                if (container != null) {
                    player.method_17355(
                            new class_747(
                                    (syncId, playerInventory, playerEntity) ->
                                            new LunchBoxMenu(
                                                    syncId,
                                                    playerInventory,
                                                    container
                                            ),
                                    class_2561.method_43471(this.method_7866(stack))
                            )
                    );
                }
            }

            return class_1271.method_22430(stack);
        }

        return super.method_7836(world, player, hand);
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 entity) {

        if (stack.method_7909() instanceof LunchBoxItem) {

            if (entity instanceof class_1657) {

                Integer activeSlot = getActiveFoodItemSlot(stack);

                if (activeSlot != null) {

                    LunchBoxContainer container = LunchBoxContainer.get(stack);

                    if (container != null) {

                        class_1799 selectedStack = container.method_5438(activeSlot);

                        if (!selectedStack.method_7960()) {

                            class_1799 resultStack =
                                    selectedStack.method_7910(world, entity);

                            container.method_5447(activeSlot, resultStack);
                            container.save();
                        }
                    }
                }
            }

            return stack;
        }

        return super.method_7861(stack, world, entity);
    }

    @Override
    public int method_7881(class_1799 stack) {

        if (stack.method_7909() instanceof LunchBoxItem) {

            class_1799 activeStack = getActiveFoodItemStack(stack);

            if (activeStack != null)
                return activeStack.method_7935();
        }

        return 32;
    }

    @Override
    public class_1839 method_7853(class_1799 stack) {

        if (stack.method_7909() instanceof LunchBoxItem) {

            class_1799 activeStack = getActiveFoodItemStack(stack);

            if (activeStack != null)
                return activeStack.method_7976();
        }

        return super.method_7853(stack);
    }

    @Override
    public class_2561 method_7864(class_1799 stack) {

        if (stack.method_7909() instanceof LunchBoxItem) {

            class_1799 activeStack = getActiveFoodItemStack(stack);

            if (activeStack != null) {
                return class_2561.method_43471(this.method_7866(stack))
                        .method_27693(" (")
                        .method_10852(activeStack.method_7964())
                        .method_27693(")");
            }
        }

        return super.method_7864(stack);
    }

    @Override
    public void method_7851(
            class_1799 stack,
            class_1937 world,
            List<class_2561> list,
            class_1836 context
    ) {
        if (class_437.method_25442()) {

            list.add(
                    class_2561.method_43471("message.item.lunchbox")
                            .method_27692(class_124.field_1080)
            );

        } else {

            list.add(
                    class_2561.method_43471("nutritionalbalance.tooltip.press_shift")
                            .method_27692(class_124.field_1063)
            );
        }
    }

    public void setActiveFood(
            class_1799 lunchBoxStack,
            class_1799 targetItemStack
    ) {
        setActiveFood(lunchBoxStack, targetItemStack, false);
    }

    public void setActiveFood(
            class_1799 lunchBoxStack,
            class_1799 targetItemStack,
            Boolean sync
    ) {
        if (
                lunchBoxStack.method_7909() instanceof LunchBoxItem
                        && targetItemStack.method_7909().method_19264() != null
        ) {
            setActiveFood(
                    lunchBoxStack,
                    targetItemStack.method_7909().method_7876()
            );

            if (sync) {
                ModNetworkHandler.sendToServer(
                        new LunchBoxActiveItemSync(
                                targetItemStack.method_7909().method_7876()
                        )
                );
            }
        }
    }

    public void setActiveFood(
            class_1799 lunchBoxStack,
            String descriptionId
    ) {
        if (!(lunchBoxStack.method_7909() instanceof LunchBoxItem))
            return;

        net.minecraft.class_2487 tag =
                lunchBoxStack.method_7948();

        tag.method_10582("active", descriptionId);

        lunchBoxStack.method_7980(tag);
    }

    public @Nullable Integer getActiveFoodItemSlot(
            class_1799 lunchBoxStack
    ) {
        if (lunchBoxStack.method_7909() instanceof LunchBoxItem) {

            net.minecraft.class_2487 tag =
                    lunchBoxStack.method_7969();

            if (tag != null && tag.method_10545("active")) {

                LunchBoxContainer container =
                        LunchBoxContainer.get(lunchBoxStack);

                if (container != null) {

                    String activeStack =
                            tag.method_10558("active");

                    for (
                            int i = 0;
                            i < container.method_5439();
                            i++
                    ) {
                        if (
                                container.method_5438(i)
                                        .method_7909()
                                        .method_7876()
                                        .equals(activeStack)
                        ) {
                            return i;
                        }
                    }
                }
            }
        }

        return null;
    }

    public @Nullable class_1799 getItemStack(
            class_1799 lunchBoxStack,
            int slot
    ) {
        if (lunchBoxStack.method_7909() instanceof LunchBoxItem) {

            LunchBoxContainer container =
                    LunchBoxContainer.get(lunchBoxStack);

            if (container != null)
                return container.method_5438(slot);
        }

        return null;
    }

    public @Nullable class_1799 getActiveFoodItemStack(
            class_1799 lunchBoxStack
    ) {
        Integer slot =
                getActiveFoodItemSlot(lunchBoxStack);

        if (slot != null)
            return getItemStack(lunchBoxStack, slot);

        return null;
    }
}