package com.dannyandson.nutritionalbalance.lunchbox;

import com.dannyandson.nutritionalbalance.Config;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;

public class LunchBoxContainer extends class_1277 {

    public final class_1799 lunchBox;

    public static LunchBoxContainer get(class_1799 lunchBox) {
        if (lunchBox.method_7909() instanceof LunchBoxItem)
            return new LunchBoxContainer(lunchBox);
        return null;
    }

    private LunchBoxContainer(class_1799 lunchBox) {
        super(Config.LUNCHBOX_SLOT_COUNT.get());
        this.lunchBox = lunchBox;

        class_2487 tag = lunchBox.method_7969();

        if (tag != null && tag.method_10573("contents", class_2520.field_33259)) {
            method_7659(tag.method_10554("contents", class_2520.field_33260));
        }
    }

    public void save() {
        class_2499 contentsTag = method_7660();

        class_2487 tag = lunchBox.method_7948();
        tag.method_10566("contents", contentsTag);

        lunchBox.method_7980(tag);
    }
}