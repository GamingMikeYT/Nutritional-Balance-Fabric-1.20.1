package com.dannyandson.nutritionalbalance.commands;

import com.dannyandson.nutritionalbalance.effects.ModMobAffects;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_3222;

public class CommandResetPlayerEffects implements Command<class_2168> {

    private static final CommandResetPlayerEffects CMD = new CommandResetPlayerEffects();

    @Override
    public int run(CommandContext<class_2168> context) {

        if (context.getSource().method_9228() instanceof class_3222 player) {
            ModMobAffects.resetPlayerEffects(player);
        }
        return 0;
    }

    public static ArgumentBuilder<class_2168, ?> register(CommandDispatcher<class_2168> dispatcher) {
        return class_2170.method_9247("reset_player_effect")
                .requires(cs -> cs.method_9259(0))
                .executes(CMD);
    }
}