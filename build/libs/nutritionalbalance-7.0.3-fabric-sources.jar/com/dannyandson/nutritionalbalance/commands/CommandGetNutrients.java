package com.dannyandson.nutritionalbalance.commands;

import com.dannyandson.nutritionalbalance.api.INutritionalBalancePlayer;
import com.dannyandson.nutritionalbalance.api.IPlayerNutrient;
import com.dannyandson.nutritionalbalance.nutrients.PlayerNutritionData;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import java.util.StringJoiner;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class CommandGetNutrients implements Command<class_2168> {

    private static final CommandGetNutrients CMD = new CommandGetNutrients();

    @Override
    public int run(CommandContext<class_2168> context) {
        String feedback = "Must be run on client.";

        if (context.getSource().method_9228() instanceof class_3222 player) {
            INutritionalBalancePlayer iNutritionalBalancePlayer =
                    PlayerNutritionData.getWorldNutritionData().getNutritionalBalancePlayer(player);

            StringJoiner stringJoiner = new StringJoiner("\n");
            stringJoiner.add("Player Nutrition:");

            for (IPlayerNutrient nutrient : iNutritionalBalancePlayer.getPlayerNutrients()) {
                stringJoiner.add(
                        nutrient.getNutrient().name + ": "
                                + (((float) Math.round(nutrient.getValue() * 10)) / 10)
                                + " " + nutrient.getStatus().name()
                );
            }

            stringJoiner.add("Overall Status: " + iNutritionalBalancePlayer.getStatus().name());

            context.getSource().method_9226(
                    () -> class_2561.method_43470(stringJoiner.toString()),
                    false
            );
        }

        return 0;
    }

    public static ArgumentBuilder<class_2168, ?> register(
            CommandDispatcher<class_2168> dispatcher) {

        return class_2170.method_9247("get_nutrients")
                .requires(cs -> cs.method_9259(0))
                .executes(CMD);
    }
}