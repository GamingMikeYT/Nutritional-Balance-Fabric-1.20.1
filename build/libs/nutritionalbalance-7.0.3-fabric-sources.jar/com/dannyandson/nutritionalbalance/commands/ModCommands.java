package com.dannyandson.nutritionalbalance.commands;

import com.dannyandson.nutritionalbalance.NutritionalBalance;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.tree.LiteralCommandNode;
import net.minecraft.class_2168;
import net.minecraft.class_2170;

public class ModCommands {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        LiteralCommandNode<class_2168> cmdHD = dispatcher.register(
                class_2170.method_9247(NutritionalBalance.MODID)
                        .then(CommandGetNutrients.register(dispatcher))
                        .then(CommandSyncClient.register(dispatcher))
                        .then(CommandGetUnassignedFoods.register(dispatcher))
                        .then(CommandResetPlayerEffects.register(dispatcher))
                        .then(CommandSetNutrient.register(dispatcher))
        );

        dispatcher.register(
                class_2170.method_9247("nb").redirect(cmdHD)
        );
    }

}
