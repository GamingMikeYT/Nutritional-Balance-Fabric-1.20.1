package com.dannyandson.nutritionalbalance.commands;

import com.dannyandson.nutritionalbalance.api.INutritionalBalancePlayer;
import com.dannyandson.nutritionalbalance.network.ModNetworkHandler;
import com.dannyandson.nutritionalbalance.network.PlayerSync;
import com.dannyandson.nutritionalbalance.nutrients.PlayerNutritionData;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_3222;

public class CommandSyncClient implements Command<class_2168> {

    private static final CommandSyncClient CMD = new CommandSyncClient();

    @Override
    public int run(CommandContext<class_2168> context) throws CommandSyntaxException {

        final PlayerSync[] playerSync = new PlayerSync[1];

        if (context.getSource().method_9228() instanceof class_3222 player) {
            INutritionalBalancePlayer iNutritionalBalancePlayer =
                    PlayerNutritionData.getWorldNutritionData()
                            .getNutritionalBalancePlayer(player);

            playerSync[0] = new PlayerSync(iNutritionalBalancePlayer);

            ModNetworkHandler.sendToClient(
                    playerSync[0],
                    context.getSource().method_9207()
            );
        }

        return 0;
    }

    public static ArgumentBuilder<class_2168, ?> register(
            CommandDispatcher<class_2168> dispatcher) {

        return class_2170.method_9247("sync")
                .requires(cs -> cs.method_9259(0))
                .executes(CMD);
    }
}
