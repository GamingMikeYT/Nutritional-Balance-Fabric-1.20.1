package com.dannyandson.nutritionalbalance.commands;

import com.dannyandson.nutritionalbalance.api.INutritionalBalancePlayer;
import com.dannyandson.nutritionalbalance.nutrients.Nutrient;
import com.dannyandson.nutritionalbalance.nutrients.PlayerNutritionData;
import com.dannyandson.nutritionalbalance.nutrients.WorldNutrients;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class CommandSetNutrient {

    public static ArgumentBuilder<class_2168, ?> register(
            CommandDispatcher<class_2168> dispatcher) {

        return class_2170.method_9247("set_nutrient")
                .requires(cs -> cs.method_9259(3))
                .then(class_2170.method_9244(
                                "nutrient",
                                StringArgumentType.word())
                        .suggests(CommandSetNutrient::suggestNutrients)
                        .then(class_2170.method_9244(
                                        "value",
                                        FloatArgumentType.floatArg(0.0f, 180f))
                                .executes(CommandSetNutrient::setNutrients)));
    }

    public static int setNutrients(
            CommandContext<class_2168> context)
            throws CommandSyntaxException {

        if (context.getSource().method_9228() instanceof class_3222 player) {

            String nutrientName =
                    StringArgumentType.getString(context, "nutrient");

            if (!getNutrientList().contains(nutrientName)) {
                throw new SimpleCommandExceptionType(
                        class_2561.method_43470("Invalid nutrient argument")
                ).create();
            }

            INutritionalBalancePlayer iNutritionalBalancePlayer =
                    PlayerNutritionData.getWorldNutritionData()
                            .getNutritionalBalancePlayer(player);

            float value =
                    FloatArgumentType.getFloat(context, "value");

            iNutritionalBalancePlayer
                    .getPlayerNutrientByName(nutrientName)
                    .setValue(value);
        }

        return 0;
    }

    private static CompletableFuture<Suggestions> suggestNutrients(
            CommandContext<class_2168> context,
            SuggestionsBuilder builder) {

        return net.minecraft.class_2172.method_9265(
                getNutrientList(),
                builder
        );
    }

    private static List<String> getNutrientList() {

        List<String> nutrientList = new ArrayList<>();

        List<Nutrient> nutrients = WorldNutrients.get();

        for (Nutrient nutrient : nutrients) {
            nutrientList.add(nutrient.name);
        }

        return nutrientList;
    }
}