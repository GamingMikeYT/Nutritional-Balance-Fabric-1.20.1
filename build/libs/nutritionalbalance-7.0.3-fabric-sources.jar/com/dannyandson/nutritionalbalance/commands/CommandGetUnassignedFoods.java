package com.dannyandson.nutritionalbalance.commands;

import com.dannyandson.nutritionalbalance.nutrients.WorldNutrients;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.StringJoiner;
import net.minecraft.class_1792;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_7923;

public class CommandGetUnassignedFoods implements Command<class_2168> {

    private static final CommandGetUnassignedFoods CMD = new CommandGetUnassignedFoods();

    @Override
    public int run(CommandContext<class_2168> context) throws CommandSyntaxException {

        StringJoiner stringJoiner = new StringJoiner("\n");

        for (class_1792 item : class_7923.field_41178) {
            if (item.method_19264() != null
                    && WorldNutrients.getNutrients(item, context.getSource().method_9225()).size() == 0) {

                stringJoiner.add(class_7923.field_41178.method_10221(item).toString());
            }
        }

        context.getSource().method_9226(
                () -> class_2561.method_43470(stringJoiner.toString()),
                false
        );

        return 0;
    }

    public static ArgumentBuilder<class_2168, ?> register(
            CommandDispatcher<class_2168> dispatcher) {

        return class_2170.method_9247("get_unassigned_foods")
                .requires(cs -> cs.method_9259(0))
                .executes(CMD);
    }
}
