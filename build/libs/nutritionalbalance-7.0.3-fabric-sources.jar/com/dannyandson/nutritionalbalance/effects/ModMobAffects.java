
package com.dannyandson.nutritionalbalance.effects;

import com.dannyandson.nutritionalbalance.Config;
import com.dannyandson.nutritionalbalance.NutritionalBalance;
import com.dannyandson.nutritionalbalance.setup.Registration;
import net.minecraft.class_1291;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1657;
import net.minecraft.class_4081;
import net.minecraft.class_5134;

public class ModMobAffects {

    public static class Nourished extends class_1291 {
        private static final int COLOR = 3949738;

        public Nourished() {
            super(class_4081.field_18271, COLOR);
        }

        public void setAttributes() {
            addModifier(class_5134.field_23716, "8d4c1b21-6f72-4e35-9a10-2b7c5d8e4101", Config.NOURISHED_MAX_HEALTH.get(), class_1322.class_1323.field_6328);
            addModifier(class_5134.field_23718, "8d4c1b21-6f72-4e35-9a10-2b7c5d8e4102", Config.NOURISHED_KNOCKBACK_RESISTANCE.get(), class_1322.class_1323.field_6328);
            addModifier(class_5134.field_23719, "8d4c1b21-6f72-4e35-9a10-2b7c5d8e4103", Config.NOURISHED_MOVEMENT_SPEED.get(), class_1322.class_1323.field_6331);
            addModifier(class_5134.field_23721, "8d4c1b21-6f72-4e35-9a10-2b7c5d8e4104", Config.NOURISHED_ATTACK_DAMAGE.get(), class_1322.class_1323.field_6328);
            addModifier(class_5134.field_23722, "8d4c1b21-6f72-4e35-9a10-2b7c5d8e4105", Config.NOURISHED_ATTACK_KNOCKBACK.get(), class_1322.class_1323.field_6328);
            addModifier(class_5134.field_23723, "8d4c1b21-6f72-4e35-9a10-2b7c5d8e4106", Config.NOURISHED_ATTACK_SPEED.get(), class_1322.class_1323.field_6331);
        }

        private void addModifier(class_1320 attribute, String uuid, double amount, class_1322.class_1323 operation) {
            if (amount != 0d) {
                method_5566(attribute, uuid, amount, operation);
            }
        }
    }

    public static class MalNourished extends class_1291 {
        private static final int COLOR = 11546150;

        public MalNourished() {
            super(class_4081.field_18272, COLOR);
        }

        public void setAttributes() {
            addModifier(class_5134.field_23716, "9d4c1b21-6f72-4e35-9a10-2b7c5d8e4101", Config.MALNOURISHED_MAX_HEALTH.get(), class_1322.class_1323.field_6328);
            addModifier(class_5134.field_23718, "9d4c1b21-6f72-4e35-9a10-2b7c5d8e4102", Config.MALNOURISHED_KNOCKBACK_RESISTANCE.get(), class_1322.class_1323.field_6328);
            addModifier(class_5134.field_23719, "9d4c1b21-6f72-4e35-9a10-2b7c5d8e4103", Config.MALNOURISHED_MOVEMENT_SPEED.get(), class_1322.class_1323.field_6331);
            addModifier(class_5134.field_23721, "9d4c1b21-6f72-4e35-9a10-2b7c5d8e4104", Config.MALNOURISHED_ATTACK_DAMAGE.get(), class_1322.class_1323.field_6328);
            addModifier(class_5134.field_23722, "9d4c1b21-6f72-4e35-9a10-2b7c5d8e4105", Config.MALNOURISHED_ATTACK_KNOCKBACK.get(), class_1322.class_1323.field_6328);
            addModifier(class_5134.field_23723, "9d4c1b21-6f72-4e35-9a10-2b7c5d8e4106", Config.MALNOURISHED_ATTACK_SPEED.get(), class_1322.class_1323.field_6331);
        }

        private void addModifier(class_1320 attribute, String uuid, double amount, class_1322.class_1323 operation) {
            if (amount != 0d) {
                method_5566(attribute, uuid, amount, operation);
            }
        }
    }

    public static class Engorged extends class_1291 {
        private static final int COLOR = 11546150;

        public Engorged() {
            super(class_4081.field_18272, COLOR);
        }

        public void setAttributes() {
            addModifier(class_5134.field_23716, "ad4c1b21-6f72-4e35-9a10-2b7c5d8e4101", Config.ENGORGED_MAX_HEALTH.get(), class_1322.class_1323.field_6328);
            addModifier(class_5134.field_23718, "ad4c1b21-6f72-4e35-9a10-2b7c5d8e4102", Config.ENGORGED_KNOCKBACK_RESISTANCE.get(), class_1322.class_1323.field_6328);
            addModifier(class_5134.field_23719, "ad4c1b21-6f72-4e35-9a10-2b7c5d8e4103", Config.ENGORGED_MOVEMENT_SPEED.get(), class_1322.class_1323.field_6331);
            addModifier(class_5134.field_23721, "ad4c1b21-6f72-4e35-9a10-2b7c5d8e4104", Config.ENGORGED_ATTACK_DAMAGE.get(), class_1322.class_1323.field_6328);
            addModifier(class_5134.field_23722, "ad4c1b21-6f72-4e35-9a10-2b7c5d8e4105", Config.ENGORGED_ATTACK_KNOCKBACK.get(), class_1322.class_1323.field_6328);
            addModifier(class_5134.field_23723, "ad4c1b21-6f72-4e35-9a10-2b7c5d8e4106", Config.ENGORGED_ATTACK_SPEED.get(), class_1322.class_1323.field_6331);
        }

        private void addModifier(class_1320 attribute, String uuid, double amount, class_1322.class_1323 operation) {
            if (amount != 0d) {
                method_5566(attribute, uuid, amount, operation);
            }
        }
    }

    public static void resetPlayerEffects(class_1657 player) {
        if (player.method_6059(Registration.NOURISHED_EFFECT)) {
            player.method_6016(Registration.NOURISHED_EFFECT);
        }

        if (player.method_6059(Registration.MALNOURISHED_EFFECT)) {
            player.method_6016(Registration.MALNOURISHED_EFFECT);
        }

        if (player.method_6059(Registration.ENGORGED_EFFECT)) {
            player.method_6016(Registration.ENGORGED_EFFECT);
        }
    }

    public static void loadModEffects() {
        if (NutritionalBalance.modEffectsLoaded) {
            return;
        }

        ((Nourished) Registration.NOURISHED_EFFECT).setAttributes();
        ((MalNourished) Registration.MALNOURISHED_EFFECT).setAttributes();
        ((Engorged) Registration.ENGORGED_EFFECT).setAttributes();

        NutritionalBalance.modEffectsLoaded = true;
    }
}
