package com.dannyandson.nutritionalbalance.gui;

import net.minecraft.class_310;

public interface INutrientGUIScreen {

    public int getWidth();
    public int getHeight();
    public ModWidget addModWidget(ModWidget modWidget);

    public class_310 getMinecraft();
}