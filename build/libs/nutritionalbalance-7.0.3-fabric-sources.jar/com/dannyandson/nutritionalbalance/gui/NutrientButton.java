package com.dannyandson.nutritionalbalance.gui;

import com.dannyandson.nutritionalbalance.Config;
import com.dannyandson.nutritionalbalance.NutritionalBalance;
import com.dannyandson.nutritionalbalance.network.GUITrigger;
import com.dannyandson.nutritionalbalance.network.ModNetworkHandler;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_490;
import net.minecraft.class_6382;

public class NutrientButton extends class_339 {

    private final class_2960 buttonGUI =
            class_2960.method_43902(NutritionalBalance.MODID, "textures/gui/nutrient_button.png");

    private final class_2960 buttonGUIHover =
            class_2960.method_43902(NutritionalBalance.MODID, "textures/gui/nutrient_button_hover.png");

    private final class_490 gui;

    public NutrientButton(class_490 gui, class_2561 title) {
        super(
                getGuiX(gui) + Config.NUTRIENT_BUTTON_X.get(),
                getGuiY(gui) + Config.NUTRIENT_BUTTON_Y.get(),
                20,
                18,
                title
        );

        this.gui = gui;
        updateLocation();
    }

    private static int getGuiX(class_490 gui) {
        return (gui.field_22789 - 176) / 2;
    }

    private static int getGuiY(class_490 gui) {
        return (gui.field_22790 - 166) / 2;
    }

    private void updateLocation() {
        this.method_46421(getGuiX(gui) + Config.NUTRIENT_BUTTON_X.get());
        this.method_46419(getGuiY(gui) + Config.NUTRIENT_BUTTON_Y.get());
        this.field_22758 = 20;
        this.field_22759 = 18;
    }

    @Override
    public void method_25348(double mouseX, double mouseY) {
        ModNetworkHandler.sendToServer(new GUITrigger());
    }

    @Override
    protected void method_48579(
            class_332 drawContext,
            int mouseX,
            int mouseY,
            float delta
    ) {
        if (field_22764) {
            updateLocation();

            class_2960 texture;

            if (mouseX > method_46426()
                    && mouseX < method_46426() + field_22758
                    && mouseY > method_46427()
                    && mouseY < method_46427() + field_22759) {
                texture = buttonGUIHover;
            } else {
                texture = buttonGUI;
            }

            drawContext.method_25290(
                    texture,
                    method_46426(),
                    method_46427(),
                    0,
                    0,
                    field_22758,
                    field_22759,
                    256,
                    256
            );
        }
    }

    @Override
    protected void method_47399(class_6382 builder) {
    }
}