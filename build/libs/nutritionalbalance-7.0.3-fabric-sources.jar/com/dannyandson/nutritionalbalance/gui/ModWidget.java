package com.dannyandson.nutritionalbalance.gui;

import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4185;
import net.minecraft.class_6382;

public class ModWidget extends class_339 {

    public enum HAlignment {
        LEFT, CENTER, RIGHT
    }

    public enum VAlignment {
        TOP, MIDDLE, BOTTOM
    }

    private HAlignment halignment = HAlignment.LEFT;
    private VAlignment valignment = VAlignment.TOP;
    private float scale = 1.0f;
    private int color;
    private int bgcolor = -1;
    private int textWidth;
    private int textHeight;
    private class_2561 toolTipTextComponent;
    private class_2960 texture;

    public ModWidget(int x, int y, int width, int height, class_2561 title, int textColor, int bgColor) {
        super(x, y, width, height, title);
        this.color = textColor;
        this.bgcolor = bgColor;

        if (!title.getString().isEmpty()) {
            class_327 textRenderer = class_310.method_1551().field_1772;
            this.textWidth = textRenderer.method_27525(title);
            this.textHeight = textRenderer.field_2000;
        }
    }

    public ModWidget(int x, int y, int width, int height, class_2561 title, int textColor) {
        this(x, y, width, height, title, textColor, -1);
    }

    public ModWidget(int x, int y, int width, int height, class_2561 title) {
        this(x, y, width, height, title, 0xFFFFFFFF, -1);
    }

    public ModWidget(int x, int y, int width, int height, int bgColor) {
        this(x, y, width, height, class_2561.method_43473(), 0xFFFFFFFF, bgColor);
    }

    public ModWidget(int x, int y, int width, int height, class_2960 texture) {
        this(x, y, width, height, class_2561.method_43473(), 0xFFFFFFFF, -1);
        this.texture = texture;
    }

    public ModWidget setTextHAlignment(HAlignment alignment) {
        this.halignment = alignment;
        return this;
    }

    public ModWidget setTextVAlignment(VAlignment alignment) {
        this.valignment = alignment;
        return this;
    }

    public ModWidget setToolTip(class_2561 textComponent) {
        this.toolTipTextComponent = textComponent;
        return this;
    }

    @Override
    protected boolean method_25361(double mouseX, double mouseY) {
        return false;
    }

    @Override
    public void method_48579(class_332 drawContext, int mouseX, int mouseY, float delta) {
        if (!field_22764) {
            return;
        }

        // Draw the background first so it cannot cover the text or texture.
        if (bgcolor != -1) {
            drawContext.method_25294(
                    method_46426(),
                    method_46427(),
                    method_46426() + field_22758,
                    method_46427() + field_22759,
                    bgcolor
            );
        }

        if (texture != null) {
            drawContext.method_25290(
                    texture,
                    method_46426(),
                    method_46427(),
                    0,
                    0,
                    field_22758,
                    field_22759,
                    field_22758,
                    field_22759
            );
        } else if (!method_25369().getString().isEmpty()) {
            class_327 textRenderer = class_310.method_1551().field_1772;

            int drawX;
            int drawY;

            switch (halignment) {
                case CENTER:
                    drawX = method_46426() + (field_22758 - textWidth) / 2;
                    break;

                case RIGHT:
                    drawX = method_46426() + field_22758 - textWidth;
                    break;

                case LEFT:
                default:
                    drawX = method_46426();
                    break;
            }

            switch (valignment) {
                case MIDDLE:
                    drawY = method_46427() + (field_22759 - textHeight) / 2;
                    break;

                case BOTTOM:
                    drawY = method_46427() + field_22759 - textHeight;
                    break;

                case TOP:
                default:
                    drawY = method_46427();
                    break;
            }

            if (scale != 1.0f) {
                drawContext.method_51448().method_22903();
                drawContext.method_51448().method_46416(drawX, drawY, 0);
                drawContext.method_51448().method_22905(scale, scale, 1.0f);

                drawContext.method_51439(
                        textRenderer,
                        method_25369(),
                        0,
                        0,
                        color,
                        false
                );

                drawContext.method_51448().method_22909();
            } else {
                drawContext.method_51439(
                        textRenderer,
                        method_25369(),
                        drawX,
                        drawY,
                        color,
                        false
                );
            }
        }

        if (toolTipTextComponent != null
                && mouseX >= method_46426()
                && mouseX <= method_46426() + field_22758
                && mouseY >= method_46427()
                && mouseY <= method_46427() + field_22759) {
            renderHoverToolTip(drawContext, mouseX, mouseY);
        }
    }

    public void renderHoverToolTip(class_332 drawContext, int mouseX, int mouseY) {
        if (toolTipTextComponent == null) {
            return;
        }

        class_327 textRenderer = class_310.method_1551().field_1772;

        int tooltipWidth = textRenderer.method_27525(toolTipTextComponent);
        int tooltipHeight = textRenderer.field_2000;

        drawContext.method_25294(
                mouseX,
                mouseY + 10,
                mouseX + tooltipWidth + 4,
                mouseY + 10 + tooltipHeight + 4,
                0xCC000000
        );

        drawContext.method_25294(
                mouseX + 1,
                mouseY + 11,
                mouseX + tooltipWidth + 3,
                mouseY + 10 + tooltipHeight + 3,
                0xFF555555
        );

        drawContext.method_51439(
                textRenderer,
                toolTipTextComponent,
                mouseX + 3,
                mouseY + 13,
                0xFFFEFEFE,
                false
        );
    }

    @Override
    protected void method_47399(class_6382 builder) {
    }

    public static class_4185 buildButton(
            Integer xPos,
            Integer yPos,
            Integer width,
            Integer height,
            class_2561 component,
            class_4185.class_4241 onPress
    ) {
        return class_4185.method_46430(component, onPress)
                .method_46434(xPos, yPos, width, height)
                .method_46431();
    }
}
