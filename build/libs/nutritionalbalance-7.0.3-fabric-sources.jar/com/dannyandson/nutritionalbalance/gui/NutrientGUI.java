package com.dannyandson.nutritionalbalance.gui;

import com.dannyandson.nutritionalbalance.NutritionalBalance;
import com.dannyandson.nutritionalbalance.keybinding.ModKeyBindings;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class NutrientGUI extends class_437 implements INutrientGUIScreen {

    private static final int WIDTH = 250;
    private static final int HEIGHT = 155;

    private static final class_2960 GUI = class_2960.method_43902(
            NutritionalBalance.MODID,
            "textures/gui/nutrient_gui.png"
    );

    public NutrientGUI() {
        super(class_2561.method_43471("nutritionalbalance.nutrients"));
    }

    @Override
    protected void method_25426() {
        NutrientGUIHelper.init(this, WIDTH, HEIGHT);

        int relX = (this.field_22789 - WIDTH) / 2;
        int relY = (this.field_22790 - HEIGHT) / 2;

        method_37063(
                ModWidget.buildButton(
                        relX + 85,
                        relY + 128,
                        80,
                        20,
                        class_2561.method_43471("nutritionalbalance.close"),
                        button -> method_25419()
                )
        );
    }

    @Override
    public ModWidget addModWidget(ModWidget modWidget) {
        return method_37063(modWidget);
    }

    @Override
    public int getWidth() {
        return this.field_22789;
    }

    @Override
    public int getHeight() {
        return this.field_22790;
    }

    @Override
    public class_310 getMinecraft() {
        return class_310.method_1551();
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public boolean method_25404(
            int keyCode,
            int scanCode,
            int modifiers
    ) {
        class_304 nutrientKey =
                ModKeyBindings.keyBindings.get("nutrientgui");

        if (nutrientKey != null
                && (nutrientKey.method_1417(keyCode, scanCode)
                || field_22787.field_1690.field_1822.method_1417(keyCode, scanCode))) {
            method_25419();
            return true;
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(null);
    }

    @Override
    public void method_25420(class_332 drawContext) {
        // Darken the world behind the nutrition screen.
        drawContext.method_25294(
                0,
                0,
                this.field_22789,
                this.field_22790,
                0xC0101010
        );
    }

    @Override
    public void method_25394(
            class_332 drawContext,
            int mouseX,
            int mouseY,
            float delta
    ) {
        // 1. Draw the dark overlay.
        method_25420(drawContext);

        // 2. Draw the GUI background texture.
        int relX = (this.field_22789 - WIDTH) / 2;
        int relY = (this.field_22790 - HEIGHT) / 2;

        drawContext.method_25290(
                GUI,
                relX,
                relY,
                0,
                0,
                WIDTH,
                HEIGHT,
                256,
                256
        );

        // 3. Draw nutrient bars, buttons, and other widgets on top.
        super.method_25394(drawContext, mouseX, mouseY, delta);
    }

    public static void open() {
        class_310.method_1551().method_1507(new NutrientGUI());
    }
}