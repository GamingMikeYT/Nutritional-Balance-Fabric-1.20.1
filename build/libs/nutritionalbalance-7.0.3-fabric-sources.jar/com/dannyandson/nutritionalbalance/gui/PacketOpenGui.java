package com.dannyandson.nutritionalbalance.gui;

import com.dannyandson.nutritionalbalance.NutritionalBalance;
import net.minecraft.class_2960;

public record PacketOpenGui() {

    public static final class_2960 ID =
            class_2960.method_43902(NutritionalBalance.MODID, "open_gui");

    public static void handle() {
        NutrientGUI.open();
    }
}